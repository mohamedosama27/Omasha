<?php $__env->startSection('content'); ?>
    <?php
        $totalprice = 0;
    ?>
    <?php if(Session::get('number_of_items') != 0): ?>
        <link href="css/cart.css" rel="stylesheet" type="text/css" media="all" />

        <div class="container my-4">
            <div class="row">
                <!-- Cart Items -->
                <div class="col-md-8 left-details">
                    <h3 class="mb-5 text-align-right"><?php echo e(__('messages.your_cart')); ?></h3>
                    <div class="cart-items">
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="cart-item mb-3 pb-4 border-bottom">
                                <div class="d-flex">
                                    <img src="<?php echo e('images/' . $item->item->images->first()->name); ?>"
                                        alt="<?php echo e($item->item->name); ?>" width="100" class="item-image mt-2">
                                    <div class="d-flex justify-content-between w-100">
                                        <div class="ml-4 product-description">
                                            <p class="large-font mb-2 mt-1">
                                                <?php echo e(app()->getLocale() == 'ar' ? $item->item->name_ar : $item->item->name); ?>

                                            </p>

                                            <div class="small-font text-muted mb-3 extra-details">
                                                <?php if(app()->getLocale() == 'ar'): ?>
                                                    <?php if($item->style_ar != null): ?>
                                                        <p class="mb-1"><span
                                                                dir="rtl"><?php echo e($item->style_ar ?? '-'); ?></span>
                                                            :<?php echo e(__('messages.style')); ?></p>
                                                    <?php endif; ?>
                                                    <p class="mb-1"><span
                                                            dir="rtl"><?php echo e($item->color_ar ?? '-'); ?></span>
                                                        :<?php echo e(__('messages.color')); ?></p>
                                                    <?php if($item->size != null): ?>
                                                        <p class="mb-1"><span
                                                                dir="rtl"><?php echo e($item->size ?? '-'); ?></span>
                                                            :<?php echo e(__('messages.size')); ?></p>
                                                    <?php endif; ?>
                                                    <?php if($item->note != null): ?>
                                                        <p class="mb-1"><span
                                                                dir="rtl"><?php echo e($item->note ?? '-'); ?></span>
                                                            :<?php echo e(__('messages.note')); ?></p>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <?php if($item->style != null): ?>
                                                        <p class="mb-1"><?php echo e(__('messages.style')); ?>:
                                                            <?php echo e($item->style ?? '-'); ?></p>
                                                    <?php endif; ?>
                                                    <p class="mb-1"><?php echo e(__('messages.color')); ?>:
                                                        <?php echo e($item->color ?? '-'); ?></p>
                                                    <?php if($item->size != null): ?>
                                                        <p class="mb-1"><?php echo e(__('messages.size')); ?>:
                                                            <?php echo e($item->size ?? '-'); ?>

                                                    <?php endif; ?>
                                                    </p>
                                                    <?php if($item->note != null): ?>
                                                        <p class="mb-1"><?php echo e(__('messages.note')); ?>:
                                                            <?php echo e($item->note ?? '-'); ?>

                                                    <?php endif; ?>
                                                    </p>
                                                <?php endif; ?>
                                            </div>

                                            <div class="d-flex align-items-center">
                                                <button class="btn btn-outline-secondary mr-3 btn-decrement"
                                                    style="font-size: 10px;" type="button" data-id="<?php echo e($item->id); ?>"
                                                    data-value=<?php echo e($item->Quantity); ?>>
                                                    <i class="fas fa-minus"></i>
                                                </button>
                                                <p id="quantity<?php echo e($item->id); ?>" class="inline mr-3 mt-2">
                                                    <?php echo e($item->Quantity); ?></p>
                                                <button class="btn btn-outline-secondary btn-sm btn-increment mr-2"
                                                    style="font-size: 10px;" type="button" data-id="<?php echo e($item->id); ?>"
                                                    data-value=<?php echo e($item->Quantity); ?>>
                                                    <i class="fas fa-plus"></i>
                                                </button>
                                                <p class="mb-0">x <?php echo e(number_format($item->price, 2)); ?>

                                                    <?php echo e(__('messages.egp')); ?></p>
                                            </div>
                                        </div>
                                        <div class="text-center price-area">
                                            <p class="mb-5 mt-2 font-weight-bold large-font">
                                                <span
                                                    id="totalprice<?php echo e($item->id); ?>"><?php echo e(number_format($item->price * $item->Quantity, 2)); ?></span>
                                                <span><?php echo e(__('messages.egp')); ?></span>
                                            </p>
                                            <a href="<?php echo e(route('removefromcart', ['id' => $item->item->id])); ?>">
                                                <button class="btn btn-secondary"><i class="fa fa-trash"></i></button>
                                            </a>
                                            <form method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>

                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php $totalprice += $item->price * $item->Quantity ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>


                <!-- Order Summary -->
                <div class="col-md-4 order-summary">
                    <div class="large-font">
                        <div class="card-header text-align-right">
                            <h3><?php echo e(__('messages.order_summary')); ?></h3>
                        </div>
                        <div class="card-body">
                            <div class="d-flex justify-content-between font-weight-bold mt-3 mb-5 reverse-flex">
                                <?php if(app()->getLocale() == 'en'): ?>
                                    <p class="large-font"><?php echo e(__('messages.subtotal')); ?>:</p>
                                <?php else: ?>
                                    <p class="large-font">:<?php echo e(__('messages.subtotal')); ?></p>
                                <?php endif; ?>
                                <p class="large-font"><span id="cart-subtotal"><?php echo e(number_format($totalprice, 2)); ?></span>
                                    <span><?php echo e(__('messages.egp')); ?></span>
                                </p>
                            </div>
                            <button onclick="window.location.href='<?php echo e(route('checkout')); ?>';"
                                class="btn btn-primary btn-block mt-4 brandcolor p-2 large-font"><?php echo e(__('messages.checkout')); ?></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <?php else: ?>
        <h2 style="margin-top:10%;font-size:26px;" class="battalion text-center"><?php echo e(__('messages.empty_cart')); ?></h2>
    <?php endif; ?>

    <script type="text/javascript">
        $.ajaxSetup({

            headers: {

                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

            }

        });
        $('#city').change(function() {
            var city_fee = $('#city option:selected').data('value');
            $("#cart-tax").text(city_fee);
        });
        $(document).on("click", '.btn-decrement', function(e) {
            e.preventDefault();

            var id = $(this).data('id');
            var quantity = parseInt($("#quantity" + id).text(), 10);
            if (quantity <= 1) {
                return;
            }
            $.ajax({

                type: 'POST',

                url: "<?php echo e(route('decrementItem')); ?>",

                data: {
                    id: id
                },
                datatype: 'json',

                success: function(data) {
                    $("#cart-subtotal").text(parseFloat(data.totalprice).toFixed(2));
                    $("#quantity" + id).text(data.quantity);
                    $("#totalprice" + id).text(parseFloat(data.item_total_price).toFixed(2))
                    // $("#countcart").text(data.countCart);
                }

            });

        });
        $(document).on("click", '.btn-increment', function(e) {
            e.preventDefault();

            var id = $(this).data('id');
            $.ajax({

                type: 'POST',

                url: "<?php echo e(route('incrementItem')); ?>",

                data: {
                    id: id
                },
                datatype: 'json',

                success: function(data) {

                    if (data.message === undefined) {

                        $("#quantity" + id).text(data.quantity);
                        $("#totalprice" + id).text(parseFloat(data.item_total_price).toFixed(2))
                        // $("#countcart").text(data.countCart);
                        $("#cart-subtotal").text(parseFloat(data.totalprice).toFixed(2));

                    } else {
                        $('#messaga').text(data.message)
                        $('#errormessage').modal();
                    }
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Freelance\Original Omasha\Omasha\resources\views/cart.blade.php ENDPATH**/ ?>