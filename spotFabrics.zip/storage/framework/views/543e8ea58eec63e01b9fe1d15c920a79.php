<?php $__env->startSection('content'); ?>

<div class="container my-4">
    <h2 class="mb-4">All Orders</h2>

    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mb-4">
        <div class="card-header">
            <h4>Order Date: <?php echo e($order->created_at->format('d M, Y')); ?></h4>
        </div>
        <div class="card-body">
            <!-- Customer Information -->
            <div class="mb-3">
                <strong>Username:</strong> <?php echo e($order->user->name); ?> <br><br>
                <strong>Phone:</strong> <?php echo e($order->user->phone); ?> <br><br>
                <strong>Address:</strong> <?php echo e($order->address); ?>

            </div>

            <!-- Ordered Items -->
            <table class="table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Color</th>
                        <th>Style</th>
                        <th>Size</th>
                        <th>Note</th>
                        <th>Unit Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="<?php echo e(route('item.show',['id' => $item->id])); ?>"><?php echo e($item->name); ?></a></td>
                        <td><?php echo e($item->pivot->color); ?></td>
                        <td><?php echo e($item->pivot->style); ?></td>
                        <td><?php echo e($item->pivot->size); ?></td>
                        <td><?php echo e($item->pivot->note); ?></td>
                        <td><?php echo e(number_format((float)$item->pivot->price, 2)); ?> EGP</td>
                        <td><?php echo e($item->pivot->quantity); ?></td>
                        <td><?php echo e(number_format((float)$item->pivot->price * $item->pivot->quantity, 2)); ?> EGP</td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <!-- Order Total -->
            <div class="d-flex">
                <h5><strong>Total Order Value: </strong></h5>
                <h5 class='ml-2'><strong><?php echo e(number_format($order->total_price, 2)); ?> EGP</strong></h5>
            </div>
        </div>
    </div>
    <hr class="my-4">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>



    <?php $__env->stopSection(); ?>

<?php echo $__env->make('bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Freelance\Original Omasha\Omasha\resources\views/vieworders.blade.php ENDPATH**/ ?>