<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="/css/lastorder.css">
<?php if( !empty($order) ): ?>

<div class="container my-5">
    <h2 class="mb-4">Order Details</h2>

    <!-- Order Information -->
    <div class="card mb-4">
        <div class="card-header">
            <h4>Order Summary</h4>
        </div>
        <div class="card-body">
            <!-- Order Date -->
            <div class="mb-4">
                <strong>Order Date:</strong> <?php echo e($order->created_at->format('d M, Y')); ?>

            </div>

            <!-- Total Price -->
            <div class="mb-4">
                <strong>Total Price:</strong> <?php echo e(number_format($order->total_price, 2)); ?> EGP
            </div>

            <!-- Number of Items -->
            

            <!-- Delivery Address -->
            <div class="mb-3">
                <strong>Delivery Address:</strong> <?php echo e($order->address); ?>

            </div>
        </div>
    </div>

    <!-- Order Items -->
    <div class="card">
        <div class="card-header">
            <h4>Items Ordered</h4>
        </div>
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Unit Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class='mb-4'>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e(number_format($item->pivot->price, 2)); ?> EGP</td>
                        <td><?php echo e($item->pivot->quantity); ?></td>
                        <td><?php echo e(number_format($item->pivot->price * $item->pivot->quantity, 2)); ?> EGP</td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php else: ?>
        <h2 class="battalion text-center" style="margin-top:10%;font-size:26px;">You didn't order yet</h2>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Freelance\Original Omasha\Omasha\resources\views/lastorder.blade.php ENDPATH**/ ?>