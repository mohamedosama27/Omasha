<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="/css/lastorder.css">
    <?php if(!empty($orders)): ?>
        <div class="container my-4 text-align-right">
            <h2 class="mb-4"><?php echo e(__('messages.all_orders')); ?></h2>

            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-4">
                    <div class="card-header">
                        <h4><?php echo e(__('messages.order_date')); ?>:
                            <?php echo e(app()->getLocale() == 'en' ? $order->created_at->format('d M, Y') : $order->created_at->locale('ar')->translatedFormat('d M, Y')); ?>

                        </h4>
                    </div>
                    <div class="card-body">
                        <!-- Customer Information -->
                        <div class="mb-3">
                            <strong><?php echo e(__('messages.address')); ?>:</strong> <?php echo e($order->address); ?>

                        </div>

                        <!-- Ordered Items -->
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th><?php echo e(__('messages.name')); ?></th>
                                        <th><?php echo e(__('messages.color')); ?></th>
                                        <th><?php echo e(__('messages.style')); ?></th>
                                        <th><?php echo e(__('messages.size')); ?></th>
                                        <th><?php echo e(__('messages.note')); ?></th>
                                        <th><?php echo e(__('messages.unit_price')); ?></th>
                                        <th><?php echo e(__('messages.quantity')); ?></th>
                                        <th><?php echo e(__('messages.total')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><a
                                                    href="<?php echo e(route('item.show', ['id' => $item->id])); ?>"><?php echo e(app()->getLocale() == 'en' ? $item->name : $item->name_ar); ?></a>
                                            </td>
                                            <td><?php echo e(app()->getLocale() == 'en' ? $item->pivot->color : $item->pivot->color_ar); ?>

                                            </td>
                                            <td><?php echo e(app()->getLocale() == 'en' ? $item->pivot->style ?? '-' : $item->pivot->style_ar ?? '-'); ?>

                                            </td>
                                            <td><?php echo e($item->pivot->size ?? '-'); ?></td>
                                            <td><?php echo e($item->pivot->note ?? '-'); ?></td>
                                            <td><?php echo e(number_format((float) $item->pivot->price, 2)); ?>

                                                <?php echo e(__('messages.egp')); ?></td>
                                            <td><?php echo e($item->pivot->quantity); ?></td>
                                            <td><?php echo e(number_format((float) $item->pivot->price * $item->pivot->quantity, 2)); ?>

                                                <?php echo e(__('messages.egp')); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Order Total -->
                        <div class="d-flex">
                            <h5><strong><?php echo e(__('messages.total_order_value')); ?>:&nbsp;</strong></h5>
                            <h5 class='ml-2'><strong><?php echo e(number_format($order->total_price, 2)); ?>

                                    <?php echo e(__('messages.egp')); ?></strong></h5>
                        </div>
                    </div>
                </div>
                <hr class="my-4">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <h2 class="battalion text-center" style="margin-top:10%;font-size:26px;"><?php echo e(__('messages.no_orders')); ?></h2>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Freelance\Original Omasha\Omasha\resources\views/lastorder.blade.php ENDPATH**/ ?>