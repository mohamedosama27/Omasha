<?php $__env->startSection('content'); ?>
    <style>
        @media (max-width:768px) {
            .img-fluid {
                height: 390px;
            }

            .product-name {
                font-size: 16px;
            }

            .product-quantity {
                font-size: 14px;
            }

            .product-price {
                font-size: 18px;
            }

            .order-summary {
                margin-top: 40px;
            }
        }

        #total-after {
            display: none;
        }

        #total-after-label {
            display: none;
        }
    </style>

    <div class="container my-4 raleway">
        <div class="row">
            <!-- Customer and Delivery Details Form -->
            <div class="col-md-7 text-align-right left-details">
                <h3 class="mb-4"><strong><?php echo e(__('messages.delivery_details')); ?></strong></h3>
                <form method="POST" id="checkout-form" action="<?php echo e(route('checkout.order')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <!-- Customer Details -->
                    <div class="form-group">
                        <label class="mb-2" for="address"><?php echo e(__('messages.address')); ?></label>
                        <input type="text" class="form-control" id="address" name="address" required>
                    </div>
                    <div class="form-group">
                        <label class="mb-2" for="city"><?php echo e(__('messages.city')); ?></label>
                        <input type="text" class="form-control" id="city" name="city" required>
                    </div>
                    <div class="form-group">
                        <label class="mb-2" for="governorate"><?php echo e(__('messages.governorate')); ?></label>
                        <select class="form-control" Name="governorate" id="governorate" required>
                            <?php $__currentLoopData = $fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($fee->id); ?>" data-value="<?php echo e($fee->value); ?>">
                                    <?php echo e(app()->getLocale() == 'ar' ? $fee->name_ar : $fee->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Delivery Details -->
                    <h3 class="mt-5 mb-4"><strong><?php echo e(__('messages.customer_details')); ?></strong></h3>
                    <div class="form-group">
                        <label class="mb-2" for="email"><?php echo e(__('messages.email')); ?></label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label class="mb-2" for="first_name"><?php echo e(__('messages.first_name')); ?></label>
                        <input type="text" class="form-control" id="first_name" name="first_name" required>
                    </div>
                    <div class="form-group">
                        <label class="mb-2" for="last_name"><?php echo e(__('messages.last_name')); ?></label>
                        <input type="text" class="form-control" id="last_name" name="last_name" required>
                    </div>
                    <div class="form-group">
                        <label class="mb-2" for="phone"><?php echo e(__('messages.phone')); ?></label>
                        <input type="text" class="form-control" id="phone" name="phone" required>
                    </div>
                </form>
            </div>

            <!-- Order Summary -->
            <div class="col-md-5 order-summary">
                <div class="card bg-light">
                    <div class="card-header text-align-right">
                        <h3><?php echo e(__('messages.order_summary')); ?></h3>
                    </div>
                    <div class="card-body">
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex justify-content-between align-items-center mb-4">
                                <div class="d-flex align-items-center">
                                    <img src="images\<?php echo e($item->item->images->first()->name); ?>" class="img-thumbnail"
                                        width="60">
                                    <div class="ml-3">
                                        <h5 class='product-name'>
                                            <?php echo e(app()->getLocale() == 'ar' ? $item->item->name_ar : $item->item->name); ?>

                                        </h5>
                                        <p class="mb-0 product-quantity"><?php echo e($item->Quantity); ?> x
                                            <?php echo e(number_format($item->price, 2)); ?>

                                            <?php echo e(__('messages.egp')); ?></p>
                                    </div>
                                </div>
                                <div>
                                    <h4 class="mb-0 product-price">
                                        <?php echo e(number_format($item->Quantity * $item->price, 2)); ?>

                                        <?php echo e(__('messages.egp')); ?></h4>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <hr>

                        <form method="POST" action="<?php echo e(route('promocode.apply')); ?>" class="d-flex mb-3 text-align-right">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="promo_code" class="form-control mr-2"
                                placeholder="<?php echo e(__('messages.enter_promo_code')); ?>"
                                value="<?php echo e(session('promoCodeApplied') ?? ''); ?>"
                                <?php echo e(session('promoCodeApplied') ? 'disabled' : ''); ?> required>
                            <button type="submit" class="btn btn-primary brandcolor mr-2"
                                <?php echo e(session('promoCodeApplied') ? 'disabled' : ''); ?>><?php echo e(__('messages.apply')); ?></button>
                        </form>

                        <?php if(session('error')): ?>
                            <div class="text-danger mb-2 ml-2">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>

                        <!-- Display Success Message and New Total Amount -->
                        <?php if(session('success')): ?>
                            <div class="text-success mb-2 ml-2">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>

                        <?php
                            if (session('discount', 0) != 0) {
                                if (session('type') == 'percentage') {
                                    $totalAfter = $totalAmount * session('discount');
                                } else {
                                    $totalAfter = $totalAmount - session('discount');
                                }
                            }
                        ?>

                        <div>
                            <?php if(app()->getLocale() == 'en'): ?>
                                <div class='d-flex justify-content-between reverse-flex'>
                                    <h6 id='total-before-label'><?php echo e(__('messages.total')); ?>:</h6>
                                    <h5 class='product-price' id='total-before'><?php echo e(number_format($totalAmount, 2)); ?>

                                        <?php echo e(__('messages.egp')); ?>

                                    </h5>
                                </div>
                                <?php if(session('discount', 0) != 0): ?>
                                    <div class='d-flex justify-content-between reverse-flex'>
                                        <h6 id='total-after-label'><?php echo e(__('messages.total')); ?>:</h6>
                                        <h5 class='product-price' id='total-after'>
                                            <?php echo e(number_format($totalAfter, 2)); ?>

                                            <?php echo e(__('messages.egp')); ?>

                                        </h5>
                                    </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class='d-flex justify-content-between reverse-flex'>
                                    <h6 id='total-before-label'>:<?php echo e(__('messages.total')); ?></h6>
                                    <h5 class='product-price' id='total-before'><?php echo e(number_format($totalAmount, 2)); ?>

                                        <?php echo e(__('messages.egp')); ?>

                                    </h5>
                                </div>
                                <?php if(session('discount', 0) != 0): ?>
                                    <div class='d-flex justify-content-between reverse-flex'>
                                        <h6 id='total-after-label'>:<?php echo e(__('messages.total')); ?></h6>
                                        <h5 class='product-price' id='total-after'>
                                            <?php echo e(number_format($totalAfter, 2)); ?>

                                            <?php echo e(__('messages.egp')); ?>

                                        </h5>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>

                        <div class="d-flex justify-content-between reverse-flex mt-1">
                            <?php if(app()->getLocale() == 'en'): ?>
                                <h6><?php echo e(__('messages.delivery_fees')); ?>:</h6>
                                <h5 id='delivery-fees' class='product-price'></h5>
                            <?php else: ?>
                                <h6>:<?php echo e(__('messages.delivery_fees')); ?></h6>
                                <h5 id='delivery-fees' class='product-price'></h5>
                            <?php endif; ?>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between font-weight-bold reverse-flex">
                            <?php if(app()->getLocale() == 'en'): ?>
                                <h6><?php echo e(__('messages.grand_total')); ?>:</h6>
                                <h5 id='grand-total' class='product-price'></h5>
                            <?php else: ?>
                                <h6>:<?php echo e(__('messages.grand_total')); ?></h6>
                                <h5 id='grand-total' class='product-price'></h5>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class='d-flex justify-content-center'>
                    <button type='button' name='submit' onclick="submitForm()"
                        class="btn btn-primary mt-5 brandcolor w-75"><?php echo e(__('messages.confirm_order')); ?></button>
                </div>
            </div>
        </div>
    </div>

    <script>
        function submitForm() {
            document.getElementById('checkout-form').submit();
        }

        document.addEventListener('DOMContentLoaded', function() {
            const governorateDropdown = document.getElementById('governorate');
            const deliveryFeesElement = document.getElementById('delivery-fees');
            const grandTotalElement = document.getElementById('grand-total');
            const totalBefore = document.getElementById('total-before');
            const totalBeforeLabel = document.getElementById('total-before-label');
            const totalAfter = document.getElementById('total-after');
            const totalAfterLabel = document.getElementById('total-after-label');

            function updateDeliveryFees() {
                const selectedOption = governorateDropdown.options[governorateDropdown.selectedIndex];
                const deliveryFee = parseFloat(selectedOption.getAttribute('data-value'));
                let discount = <?php echo e(session('discount', 0)); ?>;
                let discountType = "<?php echo e(session('type', '')); ?>";
                console.log(discount);

                let totalAmount = <?php echo e($totalAmount); ?>;
                if (discountType == 'percentage') {
                    totalAmount *= discount;
                } else if (discountType == 'amount') {
                    totalAmount -= discount;
                }
                console.log(totalAmount);

                deliveryFeesElement.textContent = deliveryFee.toLocaleString('en-US', {
                    minimumFractionDigits: 2
                }) + ' <?php echo e(__('messages.egp')); ?>';

                const grandTotal = totalAmount + deliveryFee;
                grandTotalElement.textContent = grandTotal.toLocaleString('en-US', {
                    minimumFractionDigits: 2
                }) + ' <?php echo e(__('messages.egp')); ?>';
                if (discount != 0) {
                    totalBefore.style.textDecoration = 'line-through';
                    totalBeforeLabel.style.textDecoration = 'line-through';
                    totalAfter.style.display = 'block';
                    totalAfterLabel.style.display = 'block';
                }
            }

            updateDeliveryFees();

            governorateDropdown.addEventListener('change', function() {
                updateDeliveryFees();
            });

            <?php if(session('success')): ?>
                updateDeliveryFees();
            <?php endif; ?>
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Freelance\Original Omasha\Omasha\resources\views/checkout.blade.php ENDPATH**/ ?>