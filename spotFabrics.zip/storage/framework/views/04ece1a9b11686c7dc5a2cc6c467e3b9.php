<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="/css/login.css">



    <div class="form center-block">
        <p class="text-center raleway formheader">LOGIN</p>
        <br>

        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>

            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-envelope formicon"></i></span>
                <input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>"
                    type="email" placeholder="Email" name="email" required autocomplete="email" autofocus>
            </div>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span role="alert" style="color:red;">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <br>
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-key formicon"></i></span>
                <input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password" placeholder="Password"
                    name="password" required autocomplete="current-password">
            </div>

            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span role="alert" style="color:red;">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <br>


            <a href="reset" class="forget-password-link pull-right"><u>Forget password?</u></a>

            <button type="submit" class= "brandcolor btn btn-block w3-round-xxlarge "
                style="margin-bottom:10px;">Login</button>
            <br>
            <div class="text-center create-account-div">
                First visit?
                <a href="register" class="create-account-link"><u>Create an account</u></a>
            </div>
        </form>

    </div>
    <!-- <a class="btn btn-lg btn-primary btn-block" href="<?php echo e(url('auth/facebook')); ?>">
     <strong>Login With Facebook</strong>
     </a> -->

    <!-- <a href="<?php echo e(url('/auth/redirect/google')); ?>" class="btn btn-primary"><i class="fa fa-google"></i> Google</a> -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Freelance\Original Omasha\Omasha\resources\views/auth/login.blade.php ENDPATH**/ ?>