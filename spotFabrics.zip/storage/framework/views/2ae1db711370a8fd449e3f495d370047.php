

<?php $__env->startSection('content'); ?>



<style>
    .cardspace{
        margin:10px;
    }
    .margintop{
        margin-top:10px;
    }
    .formicon {
    font-size: 20px;
  }
  .formheader{
    font-size: 28px;

  }
</style>
<br>
<div class="w3-card cardspace">

<div class="cardspace">
    <form method="POST" action="<?php echo e(route('register')); ?>">
    <?php echo csrf_field(); ?>
<br>
  <p class="text-center raleway formheader" >CREATE ACCOUNT</p>
  <br>
  <div class="input-group">
      <span class="input-group-addon"><i class="fa fa-user formicon"></i></span>
      <input class="form-control" type="text" placeholder="Name" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
    </div>
    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                     <span role="alert" style="color:red;">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <br>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 

 <br>
    <div class="input-group">
      <span class="input-group-addon"><i class="fa fa-envelope formicon"></i></span>
      <input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" type="email" placeholder="Email" name="email" required autocomplete="email" autofocus>
      </div>
      <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                     <span role="alert" style="color:red;">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <br>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
<br>
<div class="input-group">
      <span class="input-group-addon"><i class="fa fa-key formicon"></i></span>
      <input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password" placeholder="Password" name="password" required autocomplete="current-password">
      </div>

      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span role="alert" style="color:red;">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <br>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
    <br>

    <div class="input-group">
      <span class="input-group-addon"><i class="fa fa-key formicon"></i></span>
      <input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password" placeholder="Repeat Password" name="password_confirmation" required autocomplete="current-password">
    </div>

<br>
<div class="input-group">
      <span class="input-group-addon"><i class="fa fa-phone-square formicon"></i></span>
      <input class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" placeholder="Phone Number" value="<?php echo e(old('phone')); ?>" name="phone" required>
</div>

   <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span role="alert" style="color:red;">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <br>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    

<br>
  <button type="submit" class="w3-btn btn-block w3-round-xxlarge w3-light-blue">Sign Up</button>
  <br>
  <br>

</form>
</div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Freelance\Original Omasha\Omasha\resources\views/auth/register.blade.php ENDPATH**/ ?>