<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="/css/shop.css">
    <link rel="stylesheet" href="/css/item_design.css">

    <div class="container my-5">
        <div class="row">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="product col-xs-6 col-md-3">

                    <div class="productImg mb-3">
                        <img src=<?php echo e(URL::asset("images/{$item->images->first()->name}")); ?> width="100%">

                        <button class="btn center-block" data-toggle="modal"
                            data-target="#myModal<?php echo e($item->id); ?>"><?php echo e(__('messages.quick_view')); ?></button>
                    </div>
                    <!-- Modal -->
                    <div class="modal fade" id="myModal<?php echo e($item->id); ?>" role="dialog">
                        <div class="modal-dialog modal-lg">
                            <!-- Modal content-->
                            <div class="modal-content quickview">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <div id="carousel<?php echo e($item->id); ?>" class="carousel topCarousel" data-ride="carousel">
                                        <!-- Indicators -->
                                        

                                        <!-- Wrapper for slides -->
                                        <div class="carousel-inner" role="listbox">
                                            <?php $__currentLoopData = $item->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($loop->first): ?>
                                                    <div class="item active">
                                                        <img src=<?php echo e(URL::asset("images/{$image->name}")); ?>>
                                                    </div>
                                                <?php else: ?>
                                                    <div class="item">
                                                        <img src=<?php echo e(URL::asset("images/{$image->name}")); ?>>

                                                    </div>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            ...
                                        </div>

                                        <!-- Controls -->
                                        <a class="left carousel-control" href="#carousel<?php echo e($item->id); ?>" role="button"
                                            data-slide="prev">
                                            <i class="fa fa-3x fa-angle-left"></i>

                                        </a>
                                        <a class="right carousel-control" href="#carousel<?php echo e($item->id); ?>" role="button"
                                            data-slide="next">
                                            <i class="fa fa-3x fa-angle-right"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class='d-flex flex-column align-items-center text-center ml-1'>
                        <a href="<?php echo e(route('item.show', ['id' => $item->id])); ?>">
                            <p><?php echo e(app()->getLocale() == 'ar' ? $item->name_ar : $item->name); ?></p>
                        </a>
                        <p class='ml-1'><?php echo e($item->price); ?> EGP</p>
                        <div>
                            <?php if(Auth::check() && Auth::user()->type == 1): ?>
                                <p><b>Quantity : </b><?php echo e($item->quantity); ?></p>
                                <a href="<?php echo e(route('item.delete', ['id' => $item->id])); ?>"
                                    onclick="return confirm('Are you sure to delete <?php echo e($item->name); ?>?')">
                                    <button type="button" class="btn btn-default  brandcolor">
                                        <i class="fa fa-lg fa-trash actionIcons"></i></button></a>

                                <a href="<?php echo e(route('item.edit', ['id' => $item->id])); ?>">
                                    <button type="button" class="btn btn-default  brandcolor">
                                        <i class="fa fa-pencil actionIcons"></i></button></a>


                                <a href="<?php echo e(route('hideitem', ['id' => $item->id])); ?>">
                                    <button type="button" class="btn btn-default  brandcolor">
                                        <?php if($item->hide == 1): ?>
                                            <i class="fa fa-eye actionIcons"></i>
                                        <?php else: ?>
                                            <i class="fa fa-eye-slash actionIcons"></i>
                                        <?php endif; ?>
                                    </button></a><br>
                                
                            <?php endif; ?>

                            <a data-value="<?php echo e($item->id); ?>" class="btn-addToFavorite raleway addtowishlist ml-1">
                                <?php if(app()->getLocale() == 'en'): ?>
                                    <?php echo e(__('messages.add_to_wishlist')); ?>

                                    <img src=<?php echo e(URL::asset('images/favorite.svg')); ?> class='ml-1' width="12"
                                        height="12">
                                <?php else: ?>
                                    <img src=<?php echo e(URL::asset('images/favorite.svg')); ?> class='mr-1' width="12"
                                        height="12">
                                    <?php echo e(__('messages.add_to_wishlist')); ?>

                                <?php endif; ?>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="custom-pagination-brand-blue text-center">
        <?php echo e($items->links()); ?>

    </div>
    <?php echo $__env->make('errormessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script type="text/javascript">
        $.ajaxSetup({

            headers: {

                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

            }

        });

        $(document).on("click", '.btn-addToFavorite', function(e) {

            e.preventDefault();

            var id = $(this).data('value');;
            $.ajax({

                type: 'POST',

                url: 'addToFavorite',

                data: {
                    id: id
                },

                success: function(data) {

                    $('#messaga').text(data.message)
                    $('#errormessage').modal();
                    $(".countfavorites").text(data.countFavorites);

                }

            });
        });

        $(document).on("click", '.btn-addtocart', function(e) {

            e.preventDefault();

            var str = $(this).data('value');;
            $.ajax({

                type: 'POST',

                url: "<?php echo e(route('item.addToCart')); ?>",

                data: {
                    name: str
                },

                success: function(data) {

                    if (data.message === undefined) {

                        $(".countCart").text(data.countCart);
                        $('#messaga').text("Added Sucessfully")
                        $('#errormessage').modal();
                    } else {
                        $('#messaga').text(data.message)
                        $('#errormessage').modal();
                    }

                }

            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Freelance\Original Omasha\Omasha\resources\views/shop.blade.php ENDPATH**/ ?>