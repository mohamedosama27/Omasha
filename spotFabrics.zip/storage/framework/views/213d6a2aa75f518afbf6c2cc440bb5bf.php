<?php $__env->startComponent('mail::message'); ?>
# <?php echo e($details['title']); ?>

    
Client name : <?php echo e($details['order']->user->name); ?> <br />
Client phone : <?php echo e($details['order']->user->phone); ?> <br />
Client address : <?php echo e($details['order']->address); ?> <br />


<?php $__currentLoopData = $details['order']->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  - <?php echo e($item->pivot->quantity); ?> of <?php echo e($item->name); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php echo $__env->renderComponent(); ?>

<?php /**PATH E:\Freelance\Original Omasha\Omasha\resources\views/emails/send_order_to_admin.blade.php ENDPATH**/ ?>