<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="/css/welcome.css">
    <link rel="stylesheet" href="/css/item_design.css">

    <!-- Top  Carousel -->
    <?php if(count($home_images) > 0): ?>
        <div id="carousel-example-generic" class="carousel slide topCarousel mainCarousel" data-ride="carousel">

            <!-- Wrapper for slides -->
            <div class="carousel-inner" role="listbox">
                <?php $__currentLoopData = $home_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $home_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($loop->first): ?>
                        <div class="item active">
                            <img class="carouselImg" src=<?php echo e(URL::asset("images/{$home_image->name}")); ?> width="100%">
                        </div>
                    <?php else: ?>
                        <div class="item">
                            <img class="carouselImg" src=<?php echo e(URL::asset("images/{$home_image->name}")); ?> width="100%">
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(count($home_images) > 1): ?>
                    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
                        <i class="fa fa-3x fa-angle-left carouselArrow-left"></i>

                    </a>
                    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
                        <i class="fa fa-3x fa-angle-right carouselArrow-right"></i>
                    </a>
                <?php endif; ?>
            </div>

            <!-- Controls -->

        </div>
    <?php endif; ?>
    <!-- End Top  Carousel -->

    <!-- SHOP LATEST ARRIVALSl SECTION-->

    <h3 class="text-center raleway titles mb-4 mt-4"><?php echo e(__('messages.best_sellers')); ?></h3>
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $newArrivals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="product col-xs-6 col-md-3">

                    <div class="productImg mb-3">

                        <img src=<?php echo e(URL::asset("images/{$item->images->first()->name}")); ?> width="100%">
                        <button class="btn center-block" data-toggle="modal"
                            data-target="#myModal<?php echo e($item->id); ?>"><?php echo e(__('messages.quick_view')); ?></button>
                    </div>
                    <!-- Modal -->
                    <div class="modal fade" id="myModal<?php echo e($item->id); ?>" role="dialog">
                        <div class="modal-dialog modal-lg">

                            <!-- Modal content-->
                            <div class="modal-content quickview">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <div id="carousel<?php echo e($item->id); ?>" class="carousel topCarousel" data-ride="carousel">
                                        <!-- Indicators -->
                                        

                                        <!-- Wrapper for slides -->
                                        <div class="carousel-inner" role="listbox">
                                            <?php $__currentLoopData = $item->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($loop->first): ?>
                                                    <div class="item active">
                                                        <img src=<?php echo e(URL::asset("images/{$image->name}")); ?>>
                                                    </div>
                                                <?php else: ?>
                                                    <div class="item">
                                                        <img src=<?php echo e(URL::asset("images/{$image->name}")); ?>>

                                                    </div>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>

                                        <!-- Controls -->
                                        <a class="left carousel-control" href="#carousel<?php echo e($item->id); ?>" role="button"
                                            data-slide="prev">
                                            <i class="fa fa-3x fa-angle-left"></i>
                                        </a>
                                        <a class="right carousel-control" href="#carousel<?php echo e($item->id); ?>"
                                            role="button" data-slide="next">
                                            <i class="fa fa-3x fa-angle-right"></i>
                                        </a>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                    <div class='d-flex flex-column align-items-center text-center ml-1'>
                        <a href="<?php echo e(route('item.show', ['id' => $item->id])); ?>">
                            <p><?php echo e(app()->getLocale() == 'ar' ? $item->name_ar : $item->name); ?></p>
                        </a>
                        <p class='ml-1'><?php echo e($item->price); ?> <?php echo e(__('messages.egp')); ?></p>
                        
                        <a data-value="<?php echo e($item->id); ?>" class="btn-addToFavorite raleway addtowishlist ml-1">
                            <?php if(app()->getLocale() == 'en'): ?>
                                <?php echo e(__('messages.add_to_wishlist')); ?>

                                <img src="<?php echo e(URL::asset('images/favorite.svg')); ?>" class="ml-1" width="12"
                                    height="12">
                            <?php else: ?>
                                <img src="<?php echo e(URL::asset('images/favorite.svg')); ?>" class="mr-1" width="12"
                                    height="12">
                                <?php echo e(__('messages.add_to_wishlist')); ?>

                            <?php endif; ?>
                        </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <!-- END SHOP LATEST ARRIVALSl SECTION IN SM , MD , LG-->

    <!-- START LOGO -->
    <img class="slogo center-block" src=<?php echo e(URL::asset('images/Slogan.png')); ?>>
    <!-- END LOGO -->

    <?php $__currentLoopData = $parent_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($parentCategory->children->count() > 2): ?>
            <section class="curtains-section raleway">
                <h3 class="text-center raleway titles mb-4">
                    <?php echo e(strtoupper(app()->getLocale() == 'ar' ? $parentCategory->name_ar : $parentCategory->name)); ?></h3>
                <div class="slider-container">
                    <!-- Left Scroll Button -->
                    <?php if($parentCategory->children->count() > 3): ?>
                        <button class="slide-left brandcolor"
                            onclick="slideLeft('<?php echo e($parentCategory->id); ?>')">&#10094;</button>
                    <?php endif; ?>
                    <div class="curtain-categories" id="slider-<?php echo e($parentCategory->id); ?>">
                        <?php $__currentLoopData = $parentCategory->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="curtain-item">
                                <img src="<?php echo e(URL::asset('images/blackout.jpg')); ?>">
                                <div class="overlay">
                                    <span
                                        class="category-name"><?php echo e(app()->getLocale() == 'ar' ? $childCategory->name_ar : $childCategory->name); ?></span>
                                    <a href="<?php echo e(route('ItemController.product', ['category_name' => $childCategory->name])); ?>?num[]=<?php echo e($childCategory->id); ?>"
                                        class="view-button brandcolor"><?php echo e(__('messages.view')); ?></a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php if($parentCategory->children->count() > 3): ?>
                        <button class="slide-right brandcolor"
                            onclick="slideRight('<?php echo e($parentCategory->id); ?>')">&#10095;</button>
                    <?php endif; ?>
                </div>
            </section>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- START SUBSCRIBE -->
    <div class="subscribe text-center">
        <h6 class="raleway"><?php echo e(__('messages.subscribe_for_updates')); ?></h6>
        <form id="subscribe" class="form-inline">

            <input class="form-control" type="email" name="email" id="email"
                placeholder="<?php echo e(__('messages.enter_your_email')); ?>">
            <button type="submit" class="btn brandcolor raleway"><?php echo e(__('messages.subscribe')); ?></button>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>

                <span role="alert" style="color:red;">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </form>
    </div>
    <!-- END SUBSCRIBE -->


    <?php echo $__env->make('errormessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <script type="text/javascript">
        $.ajaxSetup({

            headers: {

                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

            }

        });

        $(document).on("click", '.btn-addToFavorite', function(e) {

            e.preventDefault();

            var id = $(this).data('value');;
            $.ajax({

                type: 'POST',

                url: 'addToFavorite',

                data: {
                    id: id
                },

                success: function(data) {

                    $('#messaga').text(data.message)
                    $('#errormessage').modal();
                    $(".countfavorites").text(data.countFavorites);

                }

            });
        });

        // $(document).on("click", '.btn-addtocart', function(e) {

        //     e.preventDefault();

        //     var str = $(this).data('value');;
        //     $.ajax({

        //         type: 'POST',

        //         url: "<?php echo e(route('item.addToCart')); ?>",

        //         data: {
        //             name: str
        //         },

        //         success: function(data) {

        //             if (data.message === undefined) {

        //                 $(".countCart").text(data.countCart);
        //                 $('#messaga').text("Added Sucessfully")
        //                 $('#errormessage').modal();
        //             } else {
        //                 $('#messaga').text(data.message)
        //                 $('#errormessage').modal();
        //             }

        //         }

        //     });
        // });


        $('#subscribe').on('submit', function(event) {
            event.preventDefault();

            email = $('#email').val();

            $.ajax({
                url: "<?php echo e(route('createSubscriber')); ?>",
                type: "POST",
                data: {
                    email: email,
                },
                success: function(response) {
                    $("#email").val('');
                    $('#messaga').text(response.success)
                    $('#errormessage').modal();

                },
            });
        });

        var currentIndex = {};

        function slideLeft(parentCategoryId) {
            var slider = document.getElementById('slider-' + parentCategoryId);
            var itemWidth = slider.querySelector('.curtain-item').offsetWidth + 20; // Item width plus margin

            if (!currentIndex[parentCategoryId]) currentIndex[parentCategoryId] = 0;

            // Calculate how many items we can scroll left
            var maxScrollLeft = Math.max(0, currentIndex[parentCategoryId] - 3);
            currentIndex[parentCategoryId] = maxScrollLeft;

            slider.scrollTo({
                left: maxScrollLeft * itemWidth,
                behavior: 'smooth'
            });
        }

        function slideRight(parentCategoryId) {
            var slider = document.getElementById('slider-' + parentCategoryId);
            var totalItems = slider.querySelectorAll('.curtain-item').length;
            var itemWidth = slider.querySelector('.curtain-item').offsetWidth + 20; // Item width plus margin

            if (!currentIndex[parentCategoryId]) currentIndex[parentCategoryId] = 0;

            // Calculate how many items we can scroll right, ensuring we don't scroll past the last item
            var maxScrollRight = Math.min(totalItems - 3, currentIndex[parentCategoryId] + 3);
            currentIndex[parentCategoryId] = maxScrollRight;

            slider.scrollTo({
                left: maxScrollRight * itemWidth,
                behavior: 'smooth'
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Freelance\Original Omasha\Omasha\resources\views/welcome.blade.php ENDPATH**/ ?>