<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="/css/item_design.css">
    <style>
        @media (max-width:450px) {
            .remove-product {
                font-size: 13px;
                padding: 4px 3px;
            }

            .btn-addtocart {
                padding: 5px 5px;
                font-size: 12px;
            }
        }
    </style>
    <div class="container my-4">
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="product col-xs-6 col-md-3">

                    <div class="productImg mb-3">
                        <img src=<?php echo e(URL::asset("images/{$item->images->first()->name}")); ?> width="100%">

                        <button class="btn center-block" data-toggle="modal"
                            data-target="#myModal<?php echo e($item->id); ?>"><?php echo e(__('messages.quick_view')); ?></button>
                    </div>
                    <!-- Modal -->
                    <div class="modal fade" id="myModal<?php echo e($item->id); ?>" role="dialog">
                        <div class="modal-dialog modal-lg">

                            <!-- Modal content-->
                            <div class="modal-content quickview">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <div id="carousel<?php echo e($item->id); ?>" class="carousel topCarousel" data-ride="carousel">
                                        <!-- Indicators -->
                                        <ol class="carousel-indicators">
                                            <?php $__currentLoopData = $item->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($loop->first): ?>
                                                    <li data-target="#carousel<?php echo e($item->id); ?>" data-slide-to="0"
                                                        class="active">
                                                        <img src=<?php echo e(URL::asset('images/Logo-2.png')); ?> width="100%">

                                                    </li>
                                                <?php else: ?>
                                                    <li data-target="#carousel<?php echo e($item->id); ?>" data-slide-to="1">
                                                        <img src=<?php echo e(URL::asset('images/Logo-2.png')); ?> width="100%">

                                                    </li>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ol>

                                        <!-- Wrapper for slides -->
                                        <div class="carousel-inner" role="listbox">
                                            <?php $__currentLoopData = $item->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($loop->first): ?>
                                                    <div class="item active">
                                                        <img src=<?php echo e(URL::asset("images/{$image->name}")); ?>>
                                                    </div>
                                                <?php else: ?>
                                                    <div class="item">
                                                        <img src=<?php echo e(URL::asset("images/{$image->name}")); ?>>

                                                    </div>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            ...
                                        </div>

                                        <!-- Controls -->
                                        <a class="left carousel-control" href="#carousel<?php echo e($item->id); ?>" role="button"
                                            data-slide="prev">
                                            <i class="fa fa-3x fa-angle-left"></i>

                                        </a>
                                        <a class="right carousel-control" href="#carousel<?php echo e($item->id); ?>"
                                            role="button" data-slide="next">
                                            <i class="fa fa-3x fa-angle-right"></i>
                                        </a>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                    <div class='d-flex flex-column align-items-center text-center ml-1'>
                        <a href="<?php echo e(route('item.show', ['id' => $item->id])); ?>">
                            <p><?php echo e(app()->getLocale() == 'ar' ? $item->name_ar : $item->name); ?></p>
                        </a>
                        <p><?php echo e($item->price); ?> LE</p>
                        <div class='text-align-right'>
                            

                            <a href="<?php echo e(route('removefromfavorites', ['id' => $item->id])); ?>">
                                <button class="remove-product btn btn-secondary">
                                    <i class="fa fa-lg fa-trash"></i>
                                </button>
                        </div>
                        </a>
                    </div>


                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="alert alert-dark" style="text-align:center;margin-bottom:20px;" role="alert">
                    <h1 style="display:center;font-size:26px;" class="battalion"><?php echo e(__('messages.empty_wishlist')); ?></h1>
                </div>
            <?php endif; ?>
        </div>
    </div>


    <?php echo $__env->make('errormessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Freelance\Original Omasha\Omasha\resources\views/favorites.blade.php ENDPATH**/ ?>