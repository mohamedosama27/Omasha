<?php $__env->startSection('content'); ?>
    <style>
        .manage-home-body {
            width: 80%;
        }

        .manage-home-body form button {
            margin: 20px;
        }

        .manage-home-body form {
            margin-top: 20px;
        }
    </style>
    <div class="container my-4">
        <h3 class="mb-5">Add Images to Home Page</h3>
        <form method="POST" action="<?php echo e(route('home.images.store')); ?>" enctype="multipart/form-data" class="form-inline mb-4">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <div class="custom-file">
                    <input type="file" class="custom-file-input" id="validatedCustomFile" Name="img[]" accept="image/*"
                        multiple>
                </div>
            </div>
            <button class="btn brandcolor" type="submit">ADD</button>
        </form>
        <table class="table">
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $home_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <th scope="row"><img height="150" src=<?php echo e(URL::asset("images/{$image->name}")); ?>></th>
                        <td><a href="<?php echo e(route('home.images.delete', ['id' => $image->id])); ?>">
                                <button type="button" class="btn btn-default" style="margin-bottom:10px;"
                                    style="color:black;"><b>Delete</b></button></a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p style="color:red;margin-left:50px;">No Images</p>
                <?php endif; ?>
            </tbody>
        </table>

        <h3 class="mb-5 mt-5">Add Sliding Text to Home Page</h3>

        <?php if(count($home_top_titles) == 0): ?>
            <form method="POST" class="form-inline" action="<?php echo e(route('home.titles.store')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <textarea class="form-control" name="content" placeholder="Enter text"></textarea>
                <button type="submit" class="btn brandcolor raleway">Add</button>
            </form>
        <?php else: ?>
            <?php $__currentLoopData = $home_top_titles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $home_top_title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form method="POST" class="form-inline"
                    action="<?php echo e(route('home.titles.update', ['id' => $home_top_title->id])); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <textarea class="form-control" name="content"> <?php echo e($home_top_title->content); ?></textarea>
                    <button type="submit" class="btn brandcolor raleway">Edit</button>
                    <a href="<?php echo e(route('home.titles.delete', ['id' => $home_top_title->id])); ?>"
                        onclick="return confirm('Are you sure to delete <?php echo e($home_top_title->content); ?>?')"
                        class="btn btn-danger raleway">
                        Delete
                    </a>
                </form>
            <?php break; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Freelance\Original Omasha\Omasha\resources\views/manage_home.blade.php ENDPATH**/ ?>