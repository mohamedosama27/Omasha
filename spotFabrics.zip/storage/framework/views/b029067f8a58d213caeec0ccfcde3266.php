<!DOCTYPE html>
<html>
<head>
    <title>Test Email</title>
</head>
<body>
    <h1>Hey</h1>
    <p>It works</p>
</body>
</html>
<?php /**PATH E:\Freelance\Original Omasha\Omasha\resources\views/emails/testEmail.blade.php ENDPATH**/ ?>