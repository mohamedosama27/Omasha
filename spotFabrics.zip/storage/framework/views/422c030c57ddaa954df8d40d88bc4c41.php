<!DOCTYPE html>
<html>

<head>
    <link rel="icon" type="image/png" sizes="96x96" href=<?php echo e(URL::asset('images/Logo-1.jpeg')); ?>>
    <title>Spot Fabrics</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/css/bootstrap.css">
    <script src="/js/jquery.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
    <script src="/js/html5shiv.min.js"></script>
    <script src="/js/Respond.js"></script>
    <link rel="stylesheet" href="/css/bar.css">
    <link rel="stylesheet" href="/css/w3schools.css">
    <?php if(app()->getLocale() == 'ar'): ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/rtl.css')); ?>">
    <?php endif; ?>
</head>

<body>
    <!-- Start Search Modal -->
    <div class="modal fade px-5 py-1" id="searchModel" role="dialog">
        <div class="modal-dialog modal-lg">

            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal">
                    &times;
                </button>
                <img src=<?php echo e(URL::asset('images/search.svg')); ?>>
                <input class="form-control" id="searchInput" type="text" placeholder="<?php echo e(__('messages.search')); ?>" />
                <div class="searchResult">

                </div>

            </div>

        </div>
    </div>
    <!-- End Search Modal -->

    
    

    <?php ($home_top_titles = \App\home_top_title::all()); ?>
    <?php $__currentLoopData = $home_top_titles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $home_top_title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="sliding-text">
            <span><?php echo e($home_top_title->content); ?> -</span>
            <span><?php echo e($home_top_title->content); ?> -</span>
            <span><?php echo e($home_top_title->content); ?> -</span>
            <span><?php echo e($home_top_title->content); ?> -</span>
            <span><?php echo e($home_top_title->content); ?> -</span>
        </div>
        <?php break; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

    <?php ($parent_categories = \App\Category::where('is_child', false)->get()); ?>
    <nav class="navbar brandcolor">
        <div class="container-fluid">

            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed navbar-icon brandcolor" data-toggle="collapse"
                    data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <i class="fas fa-bars" style="font-size: 20px;"></i>
                </button>

                <a href="<?php echo e(route('home')); ?>">
                    <img class="toplogo " src=<?php echo e(URL::asset('images/Logo-1.jpeg')); ?>></a>


                <div class="wrapper visible-xs">
                    <a href="<?php echo e(Request::is('cart') ? route('home') : route('cart')); ?>">
                        <i class="fas fa-shopping-cart text-white baricons" style="font-size: 20px;"></i>
                        <?php if(session()->has('number_of_items')): ?>
                            <span class="badge countCart" id='countcart'>
                                <?php echo e(Session::get('number_of_items')); ?>

                            </span>
                        <?php endif; ?>
                    </a>
                </div>
                <div class="wrapper visible-xs">
                    <a href="<?php echo e(route('favorites')); ?>" class="visible-xs">
                        <i class="fas fa-heart text-white baricons" style="font-size: 20px;"></i>
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(Auth::user()->favorites()->count() > 0): ?>
                                <span class="badge countfavorites">
                                    <?php ($x = Auth::user()->favorites()->count()); ?><?php echo e($x); ?>

                                </span>
                            <?php endif; ?> <?php endif; ?>
                        </a>
                    </div>

                    <a data-toggle="modal" data-target="#searchModel">
                        
                        <i class="fas fa-search text-white baricons searchlogo visible-xs" style="font-size: 20px;"></i>
                    </a>
                </div>

                <div class="collapse navbar-collapse mobile-margin brandcolor" id="bs-example-navbar-collapse-1"
                    style="margin-top: 0;">
                    <ul class="nav navbar-nav ml-1">
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(Auth::user()->type == 1): ?>
                                <li class="dropdown visible-xs">
                                    <a href="#" class="dropdown-toggle raleway" data-toggle="dropdown" role="button"
                                        aria-haspopup="true" aria-expanded="false">ACTIONS
                                        <span class="caret"></span></a>
                                    <ul class="dropdown-menu ml-3">

                                        <li><a href="<?php echo e(route('addadminview')); ?>">
                                                <i class="fa fa-plus actionicons"></i>Add Admin</a></li>


                                        <li><a href="<?php echo e(route('item.create')); ?>">
                                                <i class="fa fa-plus actionicons"></i>Add Item</a></li>

                                        <li><a href="<?php echo e(route('vieworders')); ?>">
                                                <i class="fa fa-list actionicons"></i>View Orders</a></li>

                                        <li><a href="<?php echo e(route('category.edit')); ?>">
                                                <i class="fa fa-edit actionicons"></i>Edit Categories</a></li>

                                        

                                        

                                        

                                        
                                </li>
                                <li><a href="<?php echo e(route('fee.showAll')); ?>">
                                        <i class="fa fa-truck actionicons"></i>Manage fees</a>
                                </li>
                                

                                <li><a href="<?php echo e(route('home.images.showAll')); ?>">
                                        <i class="fa fa-edit actionicons"></i>Edit home page </a>
                                </li>

                        </ul>
                        </li>
                        
                        <?php endif; ?>

                    <?php endif; ?>

                    <li>
                        <a href="<?php echo e(route('welcome')); ?>" class="raleway visible-xs"><?php echo e(__('messages.home')); ?></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('shop')); ?>" class="raleway visible-xs"><?php echo e(__('messages.shop')); ?></a>
                    </li>
                    <li class="dropdown visible-xs">
                        <a href="#" class="dropdown-toggle raleway" data-toggle="dropdown" role="button"
                            aria-haspopup="true" aria-expanded="false"><?php echo e(__('messages.products')); ?>

                            <span class="caret"></span></a>
                        <ul class="dropdown-menu text-align-right ml-3">
                            <?php $__currentLoopData = $parent_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php ($childIds = $parentCategory->children->pluck('id')->toArray()); ?>
                                <li class='mt-2'><a class="raleway"
                                        href="<?php echo e(route('ItemController.product', ['category_name' => $parentCategory->name])); ?>?num[]=<?php echo e(implode('&num[]=', $childIds)); ?>">
                                        <?php echo e(app()->getLocale() == 'ar' ? $parentCategory->name_ar : $parentCategory->name); ?></a>
                                </li>
                                <li class='mt-2'><a class="raleway"
                                        href="<?php echo e(route('ItemController.product', ['category_name' => $parentCategory->name])); ?>?num[]=<?php echo e(implode('&num[]=', $childIds)); ?>">
                                        <?php echo e(app()->getLocale() == 'ar' ? $parentCategory->name_ar : $parentCategory->name); ?></a>
                                </li>
                                <?php $__currentLoopData = $parentCategory->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="<?php echo e(app()->getLocale() == 'ar' ? 'mr-3' : 'ml-4'); ?>"><a class="raleway"
                                            href="<?php echo e(route('ItemController.product', ['category_name' => $childCategory->name])); ?>?num[]=<?php echo e($childCategory->id); ?>">
                                            <?php echo e(app()->getLocale() == 'ar' ? $childCategory->name_ar : $childCategory->name); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <li class='mt-2'><a class="raleway" href="<?php echo e(route('shop')); ?>">
                                    <?php echo e(__('messages.view_all')); ?></a></li>
                        </ul>
                    </li>

                    
                    
                    <?php if(auth()->guard()->check()): ?>
                        
                        <li class=" login raleway visible-xs">
                            <a href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                document.getElementById('logout-form').submit();"><?php echo e(__('messages.sign_out')); ?></a>

                        </li>
                    <?php else: ?>
                        <li class=" login raleway visible-xs">
                            <a
                                href="<?php echo e(Request::is('login') ? route('home') : route('login')); ?>"><?php echo e(__('messages.sign_in')); ?></a>
                        </li>
                    <?php endif; ?>

                    <li role="separator" class="divider"></li>

                    <!-- Second list item after the divider -->
                    <div class='d-flex justify-content-center pb-2 mobile-language'>
                        <li>
                            <div class="wrapper">
                                <a href="<?php echo e(route('switch.language', ['locale' => 'en'])); ?>">English</a>
                            </div>
                        </li>

                        <li>
                            <div class="wrapper ml-4">
                                <a href="<?php echo e(route('switch.language', ['locale' => 'ar'])); ?>">العربية</a>
                            </div>
                        </li>
                    </div>

                    </ul>

                    <ul class="nav navbar-nav navbar-left hidden-xs mb-3 mt-3 ml-3">
                        <li>
                            <div class="wrapper">
                                <a href="<?php echo e(route('switch.language', ['locale' => 'en'])); ?>">English</a>
                            </div>
                        </li>

                        <li>
                            <div class="wrapper ml-4">
                                <a href="<?php echo e(route('switch.language', ['locale' => 'ar'])); ?>">العربية</a>
                            </div>
                        </li>
                    </ul>

                    <ul class="nav navbar-nav navbar-right hidden-xs mb-3">
                        <?php if(auth()->guard()->check()): ?>
                            <li class="dropdown raleway mr-4">
                                <div class='wrapper d-flex justify-content-center'>
                                    <a href="#" class="dropdown-toggle raleway" data-toggle="dropdown" role="button"
                                        aria-haspopup="true" aria-expanded="false">
                                        <i class="fas fa-user text-white baricons" style="font-size: 22px;"></i>
                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                            style="display: none;">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </a>
                                    <ul class="dropdown-menu"
                                        style="left: 40%; transform: translateX(-50%); position: absolute; top: 95%; text-align: center;">
                                        <li><a class="raleway" href="<?php echo e(route('user.edit', ['id' => Auth::user()->id])); ?>">
                                                <?php echo e(__('messages.edit_profile')); ?></a></li>
                                        <li><a class="raleway" href="<?php echo e(route('logout')); ?>"
                                                onclick="event.preventDefault();
                document.getElementById('logout-form').submit();">
                                                <?php echo e(__('messages.sign_out')); ?></a></li>
                                    </ul>
                                </div>
                            </li>
                        <?php else: ?>
                            <li class='mr-4'>
                                <div class='wrapper'>
                                    <a href="<?php echo e(route('login')); ?>" class="raleway d-flex align-items-center">
                                        <span class='mt-3 mr-3'><?php echo e(__('messages.sign_in')); ?></span>
                                        <i class="fas fa-user text-white baricons" style="font-size: 22px;"></i>
                                    </a>
                                </div>
                            </li>
                        <?php endif; ?>

                        



                        <li>
                            <div class="wrapper">
                                <a data-toggle="modal" data-target="#searchModel" class="iconsLink">
                                    
                                    
                                    <i class="fas fa-search text-white baricons" style="font-size: 22px;"></i>
                                    
                                </a>
                            </div>
                        </li>

                        <li>
                            <div class="wrapper">
                                <a href="<?php echo e(route('favorites')); ?>" class="iconsLink">
                                    
                                    <i class="fas fa-heart text-white baricons" style="font-size: 22px;"></i>
                                    <?php if(auth()->guard()->check()): ?>
                                        <?php if(Auth::user()->favorites()->count() > 0): ?>
                                            <span class="badge countfavorites">
                                                <?php ($x = Auth::user()->favorites()->count()); ?><?php echo e($x); ?>

                                            </span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </a>
                            </div>

                        </li>
                        <li>
                            <div class="wrapper">
                                <a href="<?php echo e(Request::is('cart') ? route('home') : route('cart')); ?>">
                                    
                                    <i class="fas fa-shopping-cart text-white baricons" style="font-size: 22px;"></i>
                                    <span class="badge countCart"
                                        id='countcart'><?php echo e(Session::has('number_of_items') ? Session::get('number_of_items') : ''); ?></span>
                                </a>
                            </div>
                        </li>
                    </ul>

                </div>

                <div class="secondbar <?php if(auth()->guard()->check()): ?> secondBarForAuth <?php endif; ?> hidden-xs">
                    <ul class="nav navbar-nav">
                        <li>
                            <a href="<?php echo e(route('welcome')); ?>" class="raleway"><?php echo e(__('messages.home')); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('shop')); ?>" class="raleway"><?php echo e(__('messages.shop')); ?></a>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle raleway" data-toggle="dropdown" role="button"
                                aria-haspopup="true" aria-expanded="false"><?php echo e(__('messages.products')); ?>

                                <span class="caret"></span></a>
                            
                            <ul class="dropdown-menu text-align-right">
                                <?php $__currentLoopData = $parent_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php ($childIds = $parentCategory->children->pluck('id')->toArray()); ?>
                                    <li class='mt-2'><a class="raleway"
                                            href="<?php echo e(route('ItemController.product', ['category_name' => $parentCategory->name])); ?>?num[]=<?php echo e(implode('&num[]=', $childIds)); ?>">
                                            <?php echo e(app()->getLocale() == 'ar' ? $parentCategory->name_ar : $parentCategory->name); ?></a>
                                    </li>
                                    <?php $__currentLoopData = $parentCategory->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="<?php echo e(app()->getLocale() == 'ar' ? 'mr-3' : 'ml-4'); ?>"><a class="raleway"
                                                href="<?php echo e(route('ItemController.product', ['category_name' => $childCategory->name])); ?>?num[]=<?php echo e($childCategory->id); ?>">
                                                <?php echo e(app()->getLocale() == 'ar' ? $childCategory->name_ar : $childCategory->name); ?></a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li class='mt-2'><a class="raleway" href="<?php echo e(route('shop')); ?>">
                                        <?php echo e(__('messages.view_all')); ?></a></li>
                            </ul>
                        </li>

                        
                        
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(Auth::user()->type == 1): ?>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle raleway  " data-toggle="dropdown"
                                        role="button" aria-haspopup="true"
                                        aria-expanded="false"><?php echo e(__('messages.actions')); ?>

                                        <span class="caret"></span></a>
                                    <ul class="dropdown-menu" style="direction: ltr;">

                                        <li>
                                            <a href="<?php echo e(route('addadminview')); ?>">
                                                <i class="fa fa-plus actionicons mr-2"></i>Add Admin</a>
                                        </li>

                                        <li>
                                            <a href="<?php echo e(route('item.create')); ?>">
                                                <i class="fa fa-plus actionicons mr-2"></i>Add Item</a>
                                        </li>

                                        <li><a href="<?php echo e(route('vieworders')); ?>">
                                                <i class="fa fa-list actionicons mr-2"></i>View Orders</a>
                                        </li>

                                        <li><a href="<?php echo e(route('category.edit')); ?>">
                                                <i class="fa fa-edit actionicons mr-2"></i>Edit Categories</a>
                                        </li>

                                        <li><a href="<?php echo e(route('promocode.edit')); ?>">
                                                <i class="fa fa-edit actionicons mr-2"></i>Edit Promo Codes</a>
                                        </li>

                                        

                                        

                                        

                                        
                                        
                                        <li><a href="<?php echo e(route('fee.showAll')); ?>">
                                                <i class="fa fa-truck actionicons"></i>Manage fees</a>
                                        </li>
                                        
                                        <li><a href="<?php echo e(route('home.images.showAll')); ?>">
                                                <i class="fa fa-edit actionicons"></i>Edit home page </a>
                                        </li>
                                    </ul>
                                </li>
                                
                            <?php endif; ?>
                            

                        <?php endif; ?>

                    </ul>
                </div>
            </div>

        </nav>

        <nav class="w3-sidebar w3-bar-block w3-white w3-top" style="z-index:3;width:250px;display:none;" id="senders">
            <div class="w3-container w3-display-container w3-padding-16">
                <i onclick="senders_close()" class="fa fa-remove w3-button w3-display-topright"></i>
                <h2 class="raleway w3-wide notificationHeader">
                    <b>NOTIFICATIONS</b>
                </h2>
            </div>
            <a href="<?php echo e(route('users')); ?>" class="w3-bar-item w3-button w3-white">
                <button type="submit" class="w3-btn btn-block w3-round-xxlarge w3-light-blue">Show All</button>
            </a>


            <div class="w3-padding-64 w3-large senders" style="font-weight:bold">

            </div>

        </nav>

        <?php echo $__env->yieldContent('content'); ?>


        <!-- START FOOTER SECTION-->
        <section class="footer brandcolor">
            <div class="container-fluid">
                <div class="row footer-flex">
                    <div class=" col-lg-3 col-xs-12 footer-margin">
                        <div class="col-xs-6 d-flex align-items-center justify-content-center">
                            <img class="logo" src=<?php echo e(URL::asset('images/Logo-1.jpeg')); ?>>
                        </div>
                        <div class="col-xs-6 text-align-right">

                            <h5><?php echo e(__('messages.follow_us')); ?></h5>
                            <a href="https://www.facebook.com/spot.fabric/">
                                <img class="socialIcon" src=<?php echo e(URL::asset('images/fb.png')); ?>>
                            </a>

                            <a href="https://www.instagram.com/spot.fabrics/">
                                <img class="socialIcon mt-1" src=<?php echo e(URL::asset('images/instagram.png')); ?>>
                            </a>
                        </div>
                    </div>

                    

                    <div class="col-lg-3 col-xs-12 footer-margin text-align-right">
                        <h5><?php echo e(__('messages.contact_us')); ?></h5>
                        <?php ($contacts = \App\contact::all()); ?>
                        <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><?php echo e($contact->contact); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </section>
    </body>
    <script>
        $(document).ready(function() {
            $('.dropdown-menu').on('click', function(e) {
                e.stopPropagation();
            });

            // When clicking outside of the navbar, close it and re-enable body scroll
            // $('.navbar-collapse').on('click', function(e) {
            //     e.stopPropagation();
            // });

            $('.navbar-toggle').on('click', function() {
                if ($(this).hasClass('collapsed')) {
                    // Navbar is opening, check if there are any open dropdowns
                    $('.dropdown').removeClass('show');
                    $('.dropdown-menu').removeClass('show');
                }
            });

            // Also collapse any dropdowns when the navbar is manually closed
            $('.navbar-collapse').on('hidden.bs.collapse', function() {
                $('.dropdown').removeClass('show');
                $('.dropdown-menu').removeClass('show');
            });

            $(document).on('click', function(e) {
                if (!$('.navbar-collapse').is(e.target) && $('.navbar-collapse').has(e.target).length ===
                    0) {
                    // Close the navbar and re-enable body scroll
                    $('.navbar-collapse').removeClass('in');
                    $('.dropdown').removeClass('show');
                    $('.dropdown-menu').removeClass('show');
                }
            });
        });

        $('.dropdown').on('click', function(e) {
            if ($(window).width() <= 767) {
                e.preventDefault();

                // Close any other open dropdowns
                $('.dropdown').not(this).removeClass('show');
                $('.dropdown-menu').not($(this).find('.dropdown-menu')).removeClass('show');

                // Toggle the clicked dropdown
                $(this).toggleClass('show');
                $(this).find('.dropdown-menu').toggleClass('show');
            }
        });
        $('#searchInput').keyup(function() {
            var query = $(this).val();


            var _token = $('input[name="_token"]').val();
            $.ajax({
                url: "<?php echo e(route('ItemController.search')); ?>",
                method: "POST",
                data: {
                    query: query,
                    _token: _token
                },
                success: function(data) {

                    $('.searchResult').html(data.result)

                }
            });

        });

        function senders_open() {
            document.getElementById("senders").style.display = "block";
            getSenders();
        }

        function senders_close() {
            document.getElementById("senders").style.display = "none";
        }

        $.ajaxSetup({

            headers: {

                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

            }

        });
        // <?php if(auth()->guard()->check()): ?>
        // countmessages();

        // setInterval(countmessages, 2000);
        // <?php endif; ?>
        // function countmessages() {
        //     $.ajax({

        //         type: 'POST',
        //         _token: $('meta[name=csrf_token]').attr('content'),

        //         url: "<?php echo e(route('countmessage')); ?>",

        //         data: {},
        //         datatype: 'json',

        //         success: function(data) {
        //             if (data.countmessages != 0) {
        //                 $(".countmessage").text(data.countmessages);
        //             } else {
        //                 $(".countmessage").text('');

        //             }
        //         }

        //     });
        // }

        // function getSenders() {

        //     $.ajax({

        //         type: 'POST',
        //         _token: $('meta[name=csrf_token]').attr('content'),

        //         url: "<?php echo e(route('getSenders')); ?>",

        //         data: {},
        //         datatype: 'json',

        //         success: function(data) {
        //             $(".senders").html($(data.senders));
        //         }

        //     });

        // }
    </script>
<?php /**PATH E:\Freelance\Original Omasha\Omasha\resources\views/bar.blade.php ENDPATH**/ ?>