

<?php if(auth()->guard()->check()): ?>
    <?php if(Auth::user()->type == 1): ?>
        <?php echo $__env->make('addcategory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <div class="container my-4">
        <h3 class="pb-4">Parent Categories</h3>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Arabic Name</th>
                    <th scope="col" colspan='2'>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $parentCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <form method="POST" action="<?php echo e(route('category.update', ['id' => $parentCategory->id])); ?>"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <td>
                                <input type="Text" class="form-control"Name="name" value ="<?php echo e($parentCategory->name); ?>"
                                    required>
                            </td>
                            <td>
                                <input type="Text" class="form-control"Name="name_ar" value ="<?php echo e($parentCategory->name_ar); ?>"
                                    required>
                            </td>
                            <td>
                                <button type="submit" name="submit" class="btn btn-primary mb-2">Save</button>
                        </form>
                        <a href="<?php echo e(route('category.delete', ['id' => $parentCategory->id])); ?>">
                            <button class="btn btn-danger mb-2">Delete</button></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <h3 class="py-4">Child Categories</h3>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Arabic Name</th>
                    <th scope="col">Parent Category</th>
                    <th scope="col" colspan='2'>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $childCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <form method="POST" action="<?php echo e(route('category.update', ['id' => $childCategory->id])); ?>"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <td>
                                <input type="Text" class="form-control"Name="name" value ="<?php echo e($childCategory->name); ?>"
                                    required>
                            </td>
                            <td>
                                <input type="Text" class="form-control"Name="name_ar" value ="<?php echo e($childCategory->name_ar); ?>"
                                    required>
                            </td>
                            <td>
                                <!-- Dropdown for selecting parent category -->
                                <select class="form-control" name="parent_category_id">
                                    <?php $__currentLoopData = $parentCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($parentCategory->id); ?>"
                                            <?php echo e($childCategory->parent_category_id == $parentCategory->id ? 'selected' : ''); ?>>
                                            <?php echo e($parentCategory->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                            <td>
                                <button type="submit" name="submit" class="btn btn-primary mb-2">Save</button>
                        </form>
                        <a href="<?php echo e(route('category.delete', ['id' => $childCategory->id])); ?>">
                            <button class="btn btn-danger mb-2">Delete</button></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="mt-5 ml-2">
            <button type="button" class="btn btn-primary brandcolor" data-toggle="modal" data-target="#addcategory">
                <i class="fa fa-plus actionicons"></i> Add Category
            </button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Freelance\Original Omasha\Omasha\resources\views/editcategory.blade.php ENDPATH**/ ?>