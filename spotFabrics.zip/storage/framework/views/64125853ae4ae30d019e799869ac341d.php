<?php $__env->startSection('content'); ?>
    <link href="css/wheretobuy.css" rel="stylesheet" type="text/css" media="all" />


    <div class="container my-4 text-center">
        <h3 class="mb-5">Delivery Fees by Governorate</h3>
        <form method="POST" class="form-inline text-center mb-3" action="<?php echo e(route('fee.store')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <input class="form-control mb-2" name="name" placeholder="English" required>
            <input class="form-control mb-2" name="name_ar" placeholder="Arabic" required>
            <input class="form-control mb-2" name="value" placeholder="Delivery Fees" required>
            <button type="submit" class="btn brandcolor raleway mb-2">Add</button>
        </form>
        <?php $__currentLoopData = $fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form method="POST" class="form-inline text-center mb-4" action="<?php echo e(route('fee.update', ['id' => $fee->id])); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <input class="form-control mb-2" name="name" value="<?php echo e($fee->name); ?>" required>
                <input class="form-control mb-2" name="name_ar" value="<?php echo e($fee->name_ar); ?>" required>
                <input class="form-control mb-2" name="value" value="<?php echo e($fee->value); ?>" required>
                <button type="submit" class="btn brandcolor raleway mb-2">Edit</button>
                <a href="<?php echo e(route('fee.delete', ['id' => $fee->id])); ?>"
                    onclick="return confirm('Are you sure to delete <?php echo e($fee->name); ?>?')" class="btn btn-danger raleway mb-2">
                    Delete
                </a>
            </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Freelance\Original Omasha\Omasha\resources\views/manage_fees.blade.php ENDPATH**/ ?>