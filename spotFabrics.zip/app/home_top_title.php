<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class home_top_title extends Model
{
    //
}
