<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class distributor extends Model
{
    //
}
