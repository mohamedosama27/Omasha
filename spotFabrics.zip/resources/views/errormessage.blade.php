
  <div class="modal fade" id="errormessage">
  <div class="modal-dialog ">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <h4 id="messaga" style="text-align:center" class="battalion">Modal body..</h4>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn brandcolor" data-dismiss="modal" style="color:white;">OK</button>
      </div>

    </div>
  </div>
</div>