<!DOCTYPE html>
<html>
<head>
    <title>Test Email</title>
</head>
<body>
    <h1>Hey</h1>
    <p>It works</p>
</body>
</html>
