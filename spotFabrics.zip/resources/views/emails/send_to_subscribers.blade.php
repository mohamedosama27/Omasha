@component('mail::message')
{{ $details }}
 @endcomponent
